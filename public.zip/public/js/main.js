$(function () {
  var client = new Codebird;
  var searchCount = 0;
  var count = 0;
  var pastSearches = new Array();
  var fired = false;

  client.setConsumerKey('2Sf8mVDdlBJjPWK5H1OVQ', '4v3eDHjRTNOtJwEGPYphgXa7GzwF9wITBkq44B8');
  client.setToken('1921310000-LWfr4kbzSov6BTsjVfOl6FkTpB8AB65Hu2TO94y', '6xkEOcDJp5HK9r1QrphL9VSUIvvnbrmN33adojMCGE');

  $("#query").focus();

  $( ".user_details" ).dialog({
      autoOpen: false,
      modal: true,
    });

  $("#since").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: "yy-mm-dd",
        minDate: -9, 
        maxDate: "+1D"
      });

  $("#until").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: "yy-mm-dd",
        minDate: -9, 
        maxDate: "+1D"
      });

  $("#adSearchButton").click(function(e) {
    $("#place,#since,#until,label").fadeToggle();
    $("#adSearchButton").val("Hide Advanced Search");
  });
  
  $("#searchButton").click(function(e) {
      
      document.body.style.cursor = 'wait';

      //TODO - do checks
      if($("#query").val() != "")
      { 
        if($("#history").is(':hidden'))
          $("#history").show();
        if($("#recentTitle").is(':hidden'))
          $("#recentTitle").show();

        $("#history").prepend('<a id="'+(searchCount++)+'"'+ 'href="#" title="'+$("#query").val()+'">'+$("#query").val()+'</a><br/>'); 

        $("a").on("click",onclickhistory);
      }

      else
      {
        alert("Search field is empty");
        return;
      }

      var params = {
        'q': $("#query").val(),
        'count': 50,
        'lang' : 'en',
        'include_entities' : 'true',
        // 'result_type':'popular',
       };

       if($("#place").val() != "")  params.place_id = $("#place").val();
       if($("#since").val() != "")  params.since = $("#since").val();
       if($("#until").val() != "")  params.until = $("#until").val();

       pastSearches[count++] = params;

       // console.log(pastSearches);
       // console.log(count);

       client.__call("search/tweets",params,callback);

   });

    function onclickhistory(e) {

      document.body.style.cursor = 'wait';

      // clearAllfields();

      if(!fired)
        fired = true;
      else
      {
        fired = false;
        return;
      }

      console.log(pastSearches[$(this).attr('id')]);
      $("#query").val($(this).attr('title'));

      // if(pastSearches[$(this).attr('id')] == null)

      if(pastSearches[$(this).attr('id')].place_id != null)
      {
        console.log(typeof(pastSearches[$(this).attr('id')].place_id));
        console.log(pastSearches[$(this).attr('id')].place_id);
        $("#place").val("Hello");
        $("#place").val(pastSearches[$(this).attr('id')].place_id.toString());
      }
      else
        $("#place").val("");

      if(pastSearches[$(this).attr('id')].since != null)
        $("#since").val(pastSearches[$(this).attr('id')].since);
      else
        $("#since").val("");

      if(pastSearches[$(this).attr('id')].until != null)
        $("#until").val(pastSearches[$(this).attr('id')].until);
      else
        $("#until").val("");

        client.__call(
          "search/tweets",pastSearches[$(this).attr('id')]
          /*{ 'q': $(this).attr('title'),
            'count': 50,
            'lang' : 'en',
            // 'place_id':$("#place").val(),
            // 'since': $("#since").val(),
            // 'until' : $("#until").val(),
            // 'result_type': 'mixed',
          }*/, callback);
        return;
      }

    function callback(reply) 
    {
      document.body.style.cursor = 'default';

      if(reply == null)
      {
        $(".tweets").html("<h1>Oops...Something went wrong! Please try again");
        return;
      }
      // console.log(reply);
      $('.tweets').html("");
      $('.loading').html("");
      // console.log(reply["statuses"]);

      $('.tweets').append('<h4><b>Showing Results for '+$("#query").val()+'</b></h4>');      

      for(var i=0;i<reply["statuses"].length;i++)
      {
          $('.tweets').append('<div id="tweet'+i+'"></div>');

          $('#tweet'+i).append('<div id="profile_pic"><img id="profile_pic" src="'+reply["statuses"][i]["user"]["profile_image_url"]+'"/></div>');          

          $('#tweet'+i).append('<a href="#"><span id="user" class="'+reply["statuses"][i]["user"]["id"]+'"><b>'+reply["statuses"][i]["user"]["name"] + "</b></span></a>");
          $('#tweet'+i).append('<br/><span id="status">'+reply["statuses"][i]["text"]);
          
          if(reply["statuses"][i]["entities"] != null)
          { 
            for(var j=0;j<reply["statuses"][i]["entities"].length;j++)
            {
              if(reply["statuses"][i]["entities"][j]["hashtags"] != null)
              {
                for(var k=0;k<reply["statuses"][i]["entities"][j]["hashtags"].length;k++)
                {
                  $('#tweet'+i).append('&nbsp;'+reply["statuses"][i]["entities"][j]["hashtags"][k]["text"]+'</span>'); //[0]["text"]
                }
              }
            }
          }

          if(reply["statuses"][i] != null)
          {
            var created_at = reply["statuses"][i]["created_at"].toString().split(' ');
            $('#tweet'+i).append('<br/><span id="created" style="color: rgb(102, 95, 95)">'+created_at[0]+" "+created_at[1]+" "+created_at[2]+'</span>');  
            $('#tweet'+i).append('&nbsp;&nbsp;<span id="retweets" style="color: rgb(102, 95, 95)">Retweeeted '+reply["statuses"][i]["retweet_count"]+' times </span>');
            $('#tweet'+i).append('&nbsp;&nbsp;<span id="favs" style="color: rgb(102, 95, 95)">Favorited '+reply["statuses"][i]["user"]["favourites_count"]+' times </span>');             
          }
          $('#tweet'+i).append("<br/>");

          if(i%2 === 0)
            $('#tweet'+i).css({'background-color':'#E6E6E6','padding':'10px'});
          else
            $('#tweet'+i).css({'background-color':'#FFFFFF','padding':'10px'});

      }

      $('div[id^=tweet]').mouseenter(function() {
        var id = $(this).attr('id');
        // console.log("#"+id+" #created,#"+id+" #retweets, #"+id+" #favs");
        $("#"+id+" #created,#"+id+" #retweets, #"+id+" #favs").fadeIn("fast");
       });
      $('div[id^=tweet]').mouseleave(function() {
        var id = $(this).attr('id');
        $("#"+id+" #created,#"+id+" #retweets, #"+id+" #favs").fadeOut("fast");
       });

      $('div[id^=tweet] #user').click(function() {

            document.body.style.cursor = 'wait';
            // $('.tweets').hide();
            $('.details').html("");
            $('.user_tweets').html("");

            var args = {
              'user_id' : $(this).attr('class').toString()
            };
            client.__call("users_show",args,function(reply) {

              document.body.style.cursor = 'default';
              console.log(reply["profile_background_image_url"]);

              $('.background').css({'background-image':'url('+reply["profile_background_image_url"]+')', 'opacity':'0.2'});//,'opacity':'0.2'});
              $('.details').append('<div id="user_info"><br/><img id="user_pic" src="'+reply["profile_image_url" ]+'"width="110&" height="110%"/>');
              $('.details').append('<h3><b>'+reply["name"]+'</b></h3>');
              $('.details').append('<h4 id="screenname">@'+reply["screen_name"]+'</h4>');
              $("#screenname").css({'color':reply["profile_text_color"]});

              console.log(reply["profile_text_color"]);

              $('.details').append('<span style="font-size:12px">'+reply["location"]+'</span><br/>');

              if(reply["verified"] === true)
                $('.details').append('<h4>Verified</h4>');

              $('.details').append('<span style="font-size:12px">'+reply["statuses_count"]+' tweets </span><br />');
              $('.details').append('<span style="font-size:12px">'+reply["favourites_count"]+' favorites </span><br />');

              $('.details').append('<span style="font-size:12px">'+' Follows '+reply["followers_count"]+' people</span><br />');
              $('.details').append('<span style="font-size:12px"> Followed by '+reply["friends_count"]+' people </span></div><br />');

              console.log(reply);
              // $('.user_tweets').append('<h5>'+reply["name"]+"'s most recent tweet: </h5><br/>");
              $('.user_tweets').append('<br/><b><span style="color:"'+reply["profile_text_color"]+'>'+reply["status"]["text"]+'</b><span><br/>');

              $(".user_details").dialog("open");

            });
          });

      $(".user_details #goBack").click(function() {
            $('.tweets').show();
            $('.user_details').hide();
      });

      $('#user').css({'padding-top':'20px'});
  }

});
